KENYA MARINE SUPPLIES LTD - HTML PRACTICAL

Files included:
1. index.html - Home Page
2. about.html - About Us Page
3. products.html - Products and Services Page
4. contact.html - Contact Us Page

HOW TO USE:
- Keep all four HTML files in the same folder.
- Open index.html in a web browser to view the website.
- Click the navigation links to move between pages.
- Internet access is needed for the example images to load.
- The phone number and email in contact.html are sample details; replace them if your lecturer gives you actual details.

For GitHub Pages, upload all four HTML files to the same repository. The home page should be named index.html.
